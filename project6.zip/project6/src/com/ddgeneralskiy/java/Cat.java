package com.ddgeneralskiy.java;

public class Cat extends Animal {
    private double MAXJUMP;
    private int MAXRUN;
    private String color;
    public Cat (String name, String color, int age){
        this.name = name;
        this.color = color;
        this.age = age;
    }
    @Override
    public void SetMAX () {
        if (age > 5) {
            MAXJUMP = 1.2;
            MAXRUN = 150;
        }
        else {
            MAXJUMP = 2.3;
            MAXRUN = 250;
        }
    }

    @Override
    public void Run (int run){
        if (run <= MAXRUN) {
            System.out.println(name + " пробегает " + run + " м");
        } else System.out.println("Этот кот так не умеет!");
    }

    @Override
    public void Jump(double jump) {
        if (jump <= MAXJUMP) {
            System.out.println(name + " прыгает на " + String.format("%.2g", jump) + " м");
        } else System.out.println("Этот кот так не умеет!");
    }


    @Override
    public void Swim (int swim) {
        System.out.println("Кошки не умеют плавать!");
    }
}
