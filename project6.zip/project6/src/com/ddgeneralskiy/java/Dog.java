package com.ddgeneralskiy.java;

public class Dog extends Animal {
    private String poroda;
    private double MAXJUMP;
    private int MAXRUN;
    private int MAXSWIM;
    public Dog (String name, String poroda, int age){
        this.name = name;
        this.poroda = poroda;
        this.age = age;
    }
    @Override
    public void SetMAX(){
        if ((poroda.equals("sheepdog")) && (age <= 5)){
            MAXRUN = 750;
            MAXJUMP = 0.7;
            MAXSWIM = 15;
        }
        if ((poroda.equals("sheepdog")) && (age >= 5)){
            MAXRUN = 650;
            MAXJUMP = 0.5;
            MAXSWIM = 12;
        }
        if ((poroda.equals("collie")) && (age >= 5)){
            MAXRUN = 550;
            MAXJUMP = 0.4;
            MAXSWIM = 10;
        }
        if ((poroda.equals("collie")) && (age <= 5)){
            MAXRUN = 680;
            MAXJUMP = 0.4;
            MAXSWIM = 15;
        }


    }

    @Override
    public void Run (int run){
        if (run <= MAXRUN) {
            System.out.println(name + " пробегает " + run + " м");
        } else System.out.println("Эта собака так не умеет!");
    }

    @Override
    public void Jump(double jump) {
        if (jump <= MAXJUMP) {
            System.out.println(name + " прыгает на " + String.format("%.2g", jump) + " м");
        } else System.out.println("Эта собака так не умеет!");
    }

    @Override
    public void Swim (int swim) {
        if (swim <= MAXSWIM) {
            System.out.println(name + " проплывает " + swim + " м");
        } else System.out.println("Эта собака так не умеет!");
    }

}
