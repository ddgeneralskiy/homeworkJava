package com.ddgeneralskiy.java;

public abstract class Animal {

    protected String name;
    protected int age;
    protected double jump;
    protected int run;
    protected int swim;

    public void SetMAX(){
        //FIXME;
    }
            ;

    public void Jump (double jump) {
        System.out.println(name +" прыгает на " +  jump + "метров");
    }
    public void Run (int run){
        System.out.println(name + " пробегает " + run + "метров");
    }
    public void Swim (int swim) {
        System.out.println(name + " проплыает " + swim + "метров");
    }


    public String getName() {
      return name;
    }

    public int getage() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setage(int age) {
        age = age;
    }


}
