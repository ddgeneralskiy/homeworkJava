package com.ddgeneralskiy.java;

public class homework6 {
    public static void main(String[] args) {
        Animal[] animals = new Animal[5];
        animals [0] = new Cat("Boris", "grey", 2);
        animals [1] = new Dog("Charlie", "sheepdog", 5);
        animals [2] = new Cat("Semen", "whiteblack", 1);
        animals [3] = new Dog("Lessie", "collie", 7);
        animals [4] = new Cat("Garfield", "ginger", 11);
        for (Animal animal : animals) {
            int run;
            double jump;
            int swim;
            do {
                run = (int) (Math.random() * 1000);
                jump = (Math.random() * 10);
                swim = (int) (Math.random() * 100);
            }while ((run == 0) || (jump == 0) || (swim == 0));
            animal.SetMAX();
            animal.Run (run);
            animal.Jump (jump);
            animal.Swim (swim);
        }

    }




}
