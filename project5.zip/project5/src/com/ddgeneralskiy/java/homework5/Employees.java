package com.ddgeneralskiy.java.homework5;

import javax.swing.text.Position;

public class Employees {
    private String FIO;
    private String  Position;
    private String  Email;
    private String  Phone;
    private int Salary;
    private int Age;

    public Employees(String FIO, String Position,
                     String Email, String  Phone, int Salary,
                      int Age) {
        this.FIO = FIO;
        this.Position = Position;
        this.Email = Email;
        this.Phone = Phone;
        this.Salary = Salary;
        this.Age = Age;

    }


     public void PrintEmployees(Employees employee){

        System.out.println("Employees: " + "Fullname: " +FIO+ "Position: " +Position
                +"Email: " +Email+ "Phone: " + "Salary: " + Salary+"Age: "+Age);
    }



    public void PrintAgeMore40(){
        Employees[] employee = new Employees[5];
        employee[0] = new Employees ("Евгений Гордеев", "Начальник отдела", "egordeev@mail.ru",
                "89206203381",50000, 32);
        employee[1] = new Employees("Александр Морозов", "Главный специалист", "amorozov@mail.ru",
                "89537776341", 45000, 41);
        employee[2] = new Employees("Юрий Румянцев", "Ведущий специалист", "yrumyantsev@mail.ru",
                "89156836341", 38000, 55);
        employee[3] = new Employees("Алексей Иванов", "Ведущий специалист", "aivanov@mail.ru",
                "89203214587", 35000, 25);
        employee[4] = new Employees("Андрей Говоров", "Инженер 1-й категории", "agovorov@mail.ru",
                "89034176341", 28000, 24);
        for (int i = 0; i < employee.length; i++) {
            if (employee[i].Age > 40){
                PrintEmployees(employee[i]);

        }

        }
    }

}
