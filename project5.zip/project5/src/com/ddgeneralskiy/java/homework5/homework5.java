package homework5;

public class homework5 {
    public static void main(String[] args) {
        PrintEmployees();
        PrintAgeMore40();
    }
}
