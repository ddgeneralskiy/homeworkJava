public class Cat {
    private String name;
    private int appetite;
    private boolean satiety;
    public Cat (String name, int appetite) {
        this.name = name;
        this.appetite = appetite;
        this.satiety = false;
    }



    public void eat(Plate plate){
        if (appetite <= plate.getAmount_of_food()) {
            plate.DecreaseFood(appetite);
            appetite = 0;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAppetite() {
        return appetite;
    }

    public boolean isSatiety() {
        if (appetite == 0){
            System.out.println("Кот наелся!");
            return !satiety;
        } else {
            System.out.println("Кот хочет поесть!");
            return satiety;
        }
    }

    public void setSatiety(boolean satiety) {
        this.satiety = satiety;
    }
}
