public class homework7 {
    public static void main(String[] args) {
    Cat[] cats = new Cat[5];
    cats[0] = new Cat ("Boris", 6);
    cats[1] = new Cat ("Semen", 3);
    cats[2] = new Cat ("Max", 9);
    cats[3] = new Cat ("Tomas", 5);
    cats[4] = new Cat ("BlackCat", 4);

    Plate plate = new Plate(100);
        for (Cat cat : cats) {
            do {
                plate.info();
                cat.eat(plate);
                plate.info();
                cat.isSatiety();

                plate.IncreaseFood(100);
            } while (cat.isSatiety());
        }
    }
}
