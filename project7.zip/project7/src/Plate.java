public class Plate {
    private int amount_of_food;


    public Plate (int amount_of_food){
        this.amount_of_food = amount_of_food;
    }


    public void IncreaseFood(int i){
        if (amount_of_food == 0){
            amount_of_food = +i;
        }

    }

    public void DecreaseFood (int n){
        if (amount_of_food > 0) {
            amount_of_food = -n;
        }
    }

    public void info (){
        System.out.println("Количество еды в тарелке = " + amount_of_food);
    }

    public int getAmount_of_food() {
        return amount_of_food;
    }

    public void setAmount_of_food(int amount_of_food) {
        this.amount_of_food = amount_of_food;
    }
}
